
const WORDS=[
{word:'apple',transcr:'ˈæpəl',translation:'яблуко',example:'I ate a red apple after school.',exampleTrans:'Я з’їв червоне яблуко після школи.'},
{word:'book',transcr:'bʊk',translation:'книга',example:'She opened the book and read the first page.',exampleTrans:'Вона відкрила книгу і прочитала першу сторінку.'},
{word:'school',transcr:'skuːl',translation:'школа',example:'He goes to school by bus every day.',exampleTrans:'Він їздить до школи автобусом щодня.'}
];
const wordText=document.getElementById('wordText');
const wordTranscr=document.getElementById('wordTranscr');
const wordExample=document.getElementById('wordExample');
const wordExampleTrans=document.getElementById('wordExampleTrans');
const wordTranslation=document.getElementById('wordTranslation');
const speakBtn=document.getElementById('speakBtn');
const testBtn=document.getElementById('testBtn');
const repeatBtn=document.getElementById('repeatBtn');
const showRepeatsBtn=document.getElementById('showRepeats');
const repeatsList=document.getElementById('repeatsList');
let todayWord=null;
function pickWordOfDay(){
    const d=new Date();
    const idx=(d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate())%WORDS.length;
    return WORDS[idx];
}
function showWord(word){
    todayWord=word;
    wordText.textContent=word.word;
    wordTranscr.textContent=word.transcr?('/'+word.transcr+'/'):'';
    wordExample.textContent=word.example;
    wordExampleTrans.textContent='Переклад прикладу: '+word.exampleTrans;
    wordTranslation.textContent='Переклад слова: '+word.translation;
}
speakBtn.addEventListener('click',()=>{
    if(!todayWord)return;
    const ut=new SpeechSynthesisUtterance(todayWord.word);
    ut.lang='en-US';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ut);
});
repeatBtn.addEventListener('click',()=>{
    if(!todayWord)return;
    let div=document.createElement('div');
    div.textContent=todayWord.word;
    div.style.padding='6px 8px';
    div.style.border='1px solid #eef6ff';
    div.style.borderRadius='8px';
    div.style.marginTop='6px';
    repeatsList.appendChild(div);
});
showWord(pickWordOfDay());
